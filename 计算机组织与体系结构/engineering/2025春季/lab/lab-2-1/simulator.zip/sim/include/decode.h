#ifndef DECODE_H
#define DECODE_H

void decode_exec(Decode *s);

#endif